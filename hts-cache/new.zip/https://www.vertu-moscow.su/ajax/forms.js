var iclass="ajax-form-load";
function ajaxSuccessHtmlA(data) {						
						ajaxRemoveLoading(this);
						ajaxFormSubmitEnable(this, false); 
						this.html(data);
					}
function ajaxSuccessHtml(data) {						
						ajaxRemoveLoading(this);
						ajaxFormSubmitEnable(this, false);
						$('<div></div>').insertBefore(this).html(data);
					}					
function ajaxError(data) {
						ajaxRemoveLoading(this);
						ajaxFormSubmitEnable(this, false);
						alert('╨Ю╤И╨╕╨▒╨║╨░ ╨┐╤А╨╕ ╨╛╤В╨┐╤А╨░╨▓╨║╨╡ ╤Д╨╛╤А╨╝╤Л.');
					}

function ajaxAppendLoading($o) {
	var iw=60, ih =60;
	var pos=$o.position();
	var top = pos.top + ($o.height()-ih)/2;
	var left = pos.left+($o.width()-iw)/2;

	$o.append('<img src="/images/loading.gif" width="'+iw+'" height="'+ih+'" class="'+iclass+'" style="position:absolute; z-index:500; top:'+top+'px; left:'+left+'px;">');

}

function ajaxRemoveLoading($o) {
	$o.children('img.'+iclass).detach();
}

function ajaxFormSubmitDisable($o, val) {
	$o.find(':submit').each(function(){
		this.disabled=true;
	});
}
function ajaxFormSubmitEnable($o, val) {
	$o.find(':submit').each(function(){
		this.disabled=false;
	});
}
function ajaxSendForm(o, success, error) {
	var n = o.tagName || o.nodeName;
	if (n!='FORM') {
		o = o.parentNode;
		n = o.tagName || o.nodeName;
		if (n!='FORM') return false;
	}
	
	var fs = success || ajaxSuccessHtml;
	var fe = error || ajaxError;

	var formUrl = o.action || o.baseURI;
	var formMethod = o.method || 'get';
	$o = $(o);
	
	ajaxFormSubmitDisable($o, true);
	ajaxAppendLoading($o);
		
					$.ajax({
					url: formUrl,
					type: formMethod,
					data: $o.serialize(),
					context: $o,
					success: fs,
					error: fe
				});

	
}
function ajaxSendFormData(o, success, error) {
	var n = o.tagName || o.nodeName;
	if (n!='FORM') {
		o = o.parentNode;
		n = o.tagName || o.nodeName;
		if (n!='FORM') return false;
	}
	
	var fs = success || ajaxSuccessHtml;
	var fe = error || ajaxError;

	var formUrl = o.action || o.baseURI;
	var formMethod = o.method || 'get';
	$o = $(o);
	var fd = new FormData($o);
	
	ajaxAppendLoading($o);
		
					$.ajax({
					url: formUrl, 
					//contentType:attr( "enctype", "multipart/form-data" ),
					type: formMethod,
					data: fd,
					context: $o,
					success: fs,
					error: fe
				});

	
}

function ajaxSendSuccess2(data) {
			ajaxRemoveLoading(this);
			ajaxFormSubmitEnable(this);
			this.append('<p class="popup-auto-timer-remove">Окно будет закрыто через <span class="popup-auto-timer"></span> сек.</p>');
			
			// find or create success div
			var $div = this.parent().find('.popup-success');
			if ($div.length == 0)
				$div= $('<div class="popup-success"></div>').insertBefore(this);
			// show result
			$div.html(data);
}

function iframe_loaded(o) {
	alert($(o).contents().find('body').html());
}

function ajaxSendFormIframe(o, success, error){
	var n = o.tagName || o.nodeName;
	if (n!='FORM') {
		o = o.parentNode;
		n = o.tagName || o.nodeName;
		if (n!='FORM') return false;
	}
	
	var fs = success || ajaxSuccessHtml;
	var fe = error || ajaxError;

	var formUrl = o.action || o.baseURI;
	var formMethod = o.method || 'post';
	$o = $(o);
	
	//ajaxFormSubmitDisable($o, true);
	$f = $('#hfrm');
	if ($f.length>0 && $f[0].tagName=='IFRAME')$f[0].onload=function(){iframe_loaded(this);};

	
	return true;
}
